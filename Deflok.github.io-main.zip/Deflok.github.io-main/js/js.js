document.body.innerHTML += '<div class="body-bg"></div>'; //Создание блока в верстке с задним фоном сайта

const btnBurger = document.querySelector('.burger__menu'); //Создание константы, которая содержит кнопку для открытия моб. меню
const mobileMenu = document.querySelector('.mobile-menu'); //Создание константы, которая содержит мобильное меню
//Создание события клика по кнопке, в следствии чего изменяеться расположение меню, а также сама кнопка изменяется
btnBurger.addEventListener('click', () => {
    btnBurger.classList.toggle('_active');
    mobileMenu.classList.toggle('_active');
    document.querySelector('body').classList.toggle('_scroll-lock');
});

document.querySelector('.aside__search-form button').addEventListener('click', (e)=> {
    e.preventDefault();
    document.querySelector('.aside__search-form button').classList.toggle('_active');
    document.querySelector('.aside__search-form input').classList.toggle('_active');
});






if (document.querySelectorAll('[data-modal-link]').length > 0) {

    let modal_links = document.querySelectorAll('[data-modal-link]');
    let modal_btn_close = document.querySelectorAll('[data-modal-close]');
    let lock_padding = document.querySelectorAll('._lock-padding');
    let body = document.querySelector('body');
    let modal_unlock = true;
    let modal_timeout = 800;

    modal_links.forEach((item) => {
        item.addEventListener('click', (e) => {
            let modal_name = e.target.getAttribute('data-modal-link');
            let modal_curent = document.querySelector("#" + modal_name);
            modal_open(modal_curent);
            e.preventDefault();
        });
    });

    modal_btn_close.forEach((btn) => {
        btn.addEventListener('click', (e) => {
            modal_close(btn.closest('.modal'));
            e.preventDefault();
        });
    });


    function modal_open(modal_curent) {
        if (modal_curent && modal_unlock){
            let modal_active = document.querySelector('.modal._active');
            if (modal_active){
                modal_close(modal_active, false);
            } else {
                body_lock();
            }
            modal_curent.classList.add('_active');
            modal_curent.addEventListener('click', (e) => {
                if (!e.target.closest('.modal__dialog')){
                    modal_close(e.target.closest('.modal'));
                }
            });
        }
    }


    function modal_close (modal_active, do_un_lock = true){
        if (modal_unlock){
            modal_active.classList.remove('_active');
            if (do_un_lock){
                body_un_lock();
            }
        }
    }


    function body_lock () {
        let lock_padding_value = window.innerWidth - document.querySelector('.page').offsetWidth + 'px';

        if (lock_padding.length > 0){
            lock_padding.forEach(el => {
                el.style.paddingRight = lock_padding_value;
            });
        }

        body.style.paddingRight = lock_padding_value;
        body.classList.add('_scroll-lock');

        modal_unlock = false;
        setTimeout(() => {
            modal_unlock = true;
        }, modal_timeout);
    }

    function body_un_lock () {
        setTimeout(() => {
            if (lock_padding.length > 0){
                lock_padding.forEach(el => {
                    el.style.paddingRight = "0px";
                });
            }
           
            body.style.paddingRight = "0px";
            body.classList.remove('_scroll-lock');
        }, modal_timeout);

        modal_unlock = false;
        setTimeout(() => {
            modal_unlock = true;
        }, modal_timeout);
    }

}




"use strict";

function DynamicAdapt(type) {
	this.type = type;
}

DynamicAdapt.prototype.init = function () {
	const _this = this;
	// массив объектов
	this.оbjects = [];
	this.daClassname = "_dynamic_adapt_";
	// массив DOM-элементов
	this.nodes = document.querySelectorAll("[data-da]");

	// наполнение оbjects объктами
	for (let i = 0; i < this.nodes.length; i++) {
		const node = this.nodes[i];
		const data = node.dataset.da.trim();
		const dataArray = data.split(",");
		const оbject = {};
		оbject.element = node;
		оbject.parent = node.parentNode;
		оbject.destination = document.querySelector(dataArray[0].trim());
		оbject.breakpoint = dataArray[1] ? dataArray[1].trim() : "767";
		оbject.place = dataArray[2] ? dataArray[2].trim() : "last";
		оbject.index = this.indexInParent(оbject.parent, оbject.element);
		this.оbjects.push(оbject);
	}

	this.arraySort(this.оbjects);

	// массив уникальных медиа-запросов
	this.mediaQueries = Array.prototype.map.call(this.оbjects, function (item) {
		return '(' + this.type + "-width: " + item.breakpoint + "px)," + item.breakpoint;
	}, this);
	this.mediaQueries = Array.prototype.filter.call(this.mediaQueries, function (item, index, self) {
		return Array.prototype.indexOf.call(self, item) === index;
	});

	// навешивание слушателя на медиа-запрос
	// и вызов обработчика при первом запуске
	for (let i = 0; i < this.mediaQueries.length; i++) {
		const media = this.mediaQueries[i];
		const mediaSplit = String.prototype.split.call(media, ',');
		const matchMedia = window.matchMedia(mediaSplit[0]);
		const mediaBreakpoint = mediaSplit[1];

		// массив объектов с подходящим брейкпоинтом
		const оbjectsFilter = Array.prototype.filter.call(this.оbjects, function (item) {
			return item.breakpoint === mediaBreakpoint;
		});
		matchMedia.addListener(function () {
			_this.mediaHandler(matchMedia, оbjectsFilter);
		});
		this.mediaHandler(matchMedia, оbjectsFilter);
	}
};

DynamicAdapt.prototype.mediaHandler = function (matchMedia, оbjects) {
	if (matchMedia.matches) {
		for (let i = 0; i < оbjects.length; i++) {
			const оbject = оbjects[i];
			оbject.index = this.indexInParent(оbject.parent, оbject.element);
			this.moveTo(оbject.place, оbject.element, оbject.destination);
		}
	} else {
		for (let i = 0; i < оbjects.length; i++) {
			const оbject = оbjects[i];
			if (оbject.element.classList.contains(this.daClassname)) {
				this.moveBack(оbject.parent, оbject.element, оbject.index);
			}
		}
	}
};

// Функция перемещения
DynamicAdapt.prototype.moveTo = function (place, element, destination) {
	element.classList.add(this.daClassname);
	if (place === 'last' || place >= destination.children.length) {
		destination.insertAdjacentElement('beforeend', element);
		return;
	}
	if (place === 'first') {
		destination.insertAdjacentElement('afterbegin', element);
		return;
	}
	destination.children[place].insertAdjacentElement('beforebegin', element);
}

// Функция возврата
DynamicAdapt.prototype.moveBack = function (parent, element, index) {
	element.classList.remove(this.daClassname);
	if (parent.children[index] !== undefined) {
		parent.children[index].insertAdjacentElement('beforebegin', element);
	} else {
		parent.insertAdjacentElement('beforeend', element);
	}
}

// Функция получения индекса внутри родителя
DynamicAdapt.prototype.indexInParent = function (parent, element) {
	const array = Array.prototype.slice.call(parent.children);
	return Array.prototype.indexOf.call(array, element);
};

// Функция сортировки массива по breakpoint и place 
// по возрастанию для this.type = min
// по убыванию для this.type = max
DynamicAdapt.prototype.arraySort = function (arr) {
	if (this.type === "min") {
		Array.prototype.sort.call(arr, function (a, b) {
			if (a.breakpoint === b.breakpoint) {
				if (a.place === b.place) {
					return 0;
				}

				if (a.place === "first" || b.place === "last") {
					return -1;
				}

				if (a.place === "last" || b.place === "first") {
					return 1;
				}

				return a.place - b.place;
			}

			return a.breakpoint - b.breakpoint;
		});
	} else {
		Array.prototype.sort.call(arr, function (a, b) {
			if (a.breakpoint === b.breakpoint) {
				if (a.place === b.place) {
					return 0;
				}

				if (a.place === "first" || b.place === "last") {
					return 1;
				}

				if (a.place === "last" || b.place === "first") {
					return -1;
				}

				return b.place - a.place;
			}

			return b.breakpoint - a.breakpoint;
		});
		return;
	}
};

const da = new DynamicAdapt("max");
da.init();










